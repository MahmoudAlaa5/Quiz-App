const startBtn = document.querySelector('.questions-control .start');
const nextBtn = document.querySelector('.questions-control .next');
const prevBtn = document.querySelector('.questions-control .previous');
const categoryButtons = document.querySelectorAll('.categories button');

const questionEl = document.querySelector('.question');
const answersEl = document.querySelector('.answers');
const resultEl = document.querySelector('.result');
const bulletsEl = document.querySelector('.bullets');

let selectedCategory = null;
let allQuestionsByCategory = {};
let currentQuestions = [];
let currentIndex = 0; // index in currentQuestions (kept for compatibility)
let score = 0;
let time = 0;
let timerId = null;

// Randomization state: order of question indices
let questionOrder = [];
let orderIndex = 0; // position within questionOrder

// Map button name to JSON key
const categoryKeyMap = {
    islamic: 'islamicHistory',
    science: 'science',
    programming: 'programming',
    math: 'math',
};

// Category selection
categoryButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
        selectedCategory = btn.name;
        clearResult();
        highlightSelectedCategory(btn);
    });
});

function highlightSelectedCategory(activeBtn) {
    categoryButtons.forEach((btn) => btn.classList.remove('categories-btns'));
    activeBtn.classList.add('categories-btns');
}

function clearResult() {
    if (resultEl) resultEl.innerHTML = '';
}

// Start quiz flow
if (startBtn) {
    startBtn.addEventListener('click', async () => {
        if (!selectedCategory) {
            showMessageError('Please Choose a Category');
            return;
        }
        try {
            if (Object.keys(allQuestionsByCategory).length === 0) {
                allQuestionsByCategory = await getData('Questions.json');
            }
            const dataKey = categoryKeyMap[selectedCategory];
            currentQuestions = Array.isArray(allQuestionsByCategory[dataKey]) ? allQuestionsByCategory[dataKey] : [];

            if (currentQuestions.length === 0) {
                showMessageError('No questions found for this category.');
                return;
            }

            // Build a randomized order of question indices
            questionOrder = buildShuffledOrder(currentQuestions.length);
            orderIndex = 0;
            currentIndex = questionOrder[orderIndex];

            // Reset score/time and UI
            score = 0;
            updateScore();
            resetTimer();
            startTimer();

            // Build bullets
            renderBullets(questionOrder.length);
            updateBullets();

            disableStartBtn();
            renderCurrentQA();
        } catch (err) {
            showMessageError('Failed to load questions.');
            // Optionally log error in console
            console.error(err);
        }
    });
}

// Navigation
if (nextBtn) {
    nextBtn.addEventListener('click', () => {
        if (orderIndex < questionOrder.length - 1) {
            orderIndex += 1;
            currentIndex = questionOrder[orderIndex];
            updateBullets();
            renderCurrentQA();
        }
    });
}

if (prevBtn) {
    prevBtn.addEventListener('click', () => {
        if (orderIndex > 0) {
            orderIndex -= 1;
            currentIndex = questionOrder[orderIndex];
            updateBullets();
            renderCurrentQA();
        }
    });
}

function renderCurrentQA() {
    if (!questionEl || !answersEl) return;

    const current = currentQuestions[currentIndex];
    questionEl.textContent = current.question || '';

    // Render answers in random order
    answersEl.innerHTML = '';
    const options = Array.isArray(current.options) ? current.options : [];
    const shuffledOptions = shuffleArray(options);
    shuffledOptions.forEach((optionText) => {
        const btn = document.createElement('button');
        btn.textContent = optionText;
        btn.className = 'answer-option';
        btn.addEventListener('click', () => onAnswerClick(optionText, current.correctAnswer));
        answersEl.appendChild(btn);
    });
}

function onAnswerClick(chosen, correct) {
    const buttons = answersEl.querySelectorAll('button');
    let isChosenCorrect = false;
    buttons.forEach((b) => {
        const isCorrect = b.textContent === correct;
        if (b.textContent === chosen) {
            isChosenCorrect = isCorrect;
            b.classList.add(isCorrect ? 'correct-answer' : 'wrong-answer');
        }
        if (isCorrect) {
            b.classList.add('correct-answer');
        }
        b.disabled = true;
    });

    if (isChosenCorrect) {
        score += 1;
        updateScore();
    }

    // Stop timer if last question is answered
    if (orderIndex === questionOrder.length - 1) {
        stopTimer();
    }
}

// Bullets helpers
function renderBullets(count) {
    if (!bulletsEl) return;
    bulletsEl.innerHTML = '';
    for (let i = 0; i < count; i++) {
        const b = document.createElement('div');
        b.className = 'bullet';
        bulletsEl.appendChild(b);
    }
}

function updateBullets() {
    if (!bulletsEl) return;
    const nodes = bulletsEl.querySelectorAll('.bullet');
    nodes.forEach((node, i) => {
        node.classList.toggle('active', i === orderIndex);
    });
}

// Build a shuffled array [0..n-1]
function buildShuffledOrder(n) {
    const arr = Array.from({ length: n }, (_, i) => i);
    for (let i = n - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
}

// Returns a new shuffled copy of an array
function shuffleArray(arr) {
    const copy = arr.slice();
    for (let i = copy.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
}

async function getData(jsonFile) {
    const res = await fetch(jsonFile);
    if (!res.ok) {
        throw new Error('Network response was not ok');
    }
    return res.json();
}

function disableStartBtn() {
    if (startBtn) {
        startBtn.disabled = true;
        startBtn.style.display = 'none';
    }
    if (nextBtn) nextBtn.disabled = false;
    if (prevBtn) prevBtn.disabled = false;
    if (categoryButtons) categoryButtons.forEach((btn) => (btn.disabled = true));
}

function updateScore() {
    const scoreEl = document.querySelector('.score');
    if (!scoreEl) return;
    scoreEl.textContent = `Score: ${score}`;
}

function startTimer() {
    stopTimer();
    time = 0;
    updateTimer();
    timerId = setInterval(() => {
        time += 1;
        updateTimer();
    }, 1000);
}

function stopTimer() {
    if (timerId) {
        clearInterval(timerId);
        timerId = null;
    }
}

function resetTimer() {
    stopTimer();
    time = 0;
    updateTimer();
}

function updateTimer() {
    const timeEl = document.querySelector('.time');
    if (!timeEl) return;
    const m = Math.floor(time / 60).toString().padStart(2, '0');
    const s = (time % 60).toString().padStart(2, '0');
    timeEl.textContent = `${m}:${s}`;
}

function showMessageError(text) {
    if (!resultEl) return;
    resultEl.innerHTML = '';
    const p = document.createElement('p');
    p.textContent = text;
    p.classList.add('error-msg');
    resultEl.appendChild(p);
}




